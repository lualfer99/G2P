import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detalle-torneo-final',
  templateUrl: './detalle-torneo-final.component.html',
  styleUrls: ['./detalle-torneo-final.component.css']
})
export class DetalleTorneoFinalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
