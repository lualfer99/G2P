import { Equipos } from './equipos';

describe('Equipos', () => {
  it('should create an instance', () => {
    expect(new Equipos()).toBeTruthy();
  });
});
