import { Torneo } from './torneo';

describe('Torneo', () => {
  it('should create an instance', () => {
    expect(new Torneo()).toBeTruthy();
  });
});
