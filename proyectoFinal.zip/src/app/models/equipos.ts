export class Equipos {
}
