import { Reglas } from './reglas';

describe('Reglas', () => {
  it('should create an instance', () => {
    expect(new Reglas()).toBeTruthy();
  });
});
